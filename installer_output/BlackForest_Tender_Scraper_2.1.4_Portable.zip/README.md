# Black Forest Tender Scraper

## Installation Complete!

Thank you for installing the Black Forest Tender Scraper. This application allows you to scrape tender information from various government portals.

## Quick Start

### GUI Mode (Recommended for beginners)
1. Double-click the desktop shortcut or run `BlackForest.exe`
2. Select your desired portal from the dropdown
3. Choose departments to scrape
4. Click "Start Scraping"

### CLI Mode (For automation)
```bash
# Your most common use case
BlackForest.exe department --all

# Multi-portal support
BlackForest.exe --url "etenders" department --all

# Get help
BlackForest.exe --help
```

## Features

- ✅ **Multi-Portal Support**: 12+ tender portals supported
- ✅ **PDF & ZIP Downloads**: Automatic document downloading
- ✅ **CAPTCHA Handling**: Built-in CAPTCHA solver
- ✅ **Task Scheduler Ready**: Perfect for automated scraping
- ✅ **Excel Export**: Clean, organized tender data
- ✅ **Both GUI & CLI**: Choose your preferred interface

## Documentation

- **CLI_HELP.md**: Complete command-line documentation
- **GUI_HELP.md**: Step-by-step GUI usage guide

## System Requirements

- Windows 7 SP1 or later (64-bit)
- Python 3.7 or higher
- Google Chrome browser
- Internet connection

## Support

For issues or questions:
1. Check the logs in the `logs/` directory
2. Review the help files (CLI_HELP.md, GUI_HELP.md)
3. Ensure Python and Chrome are properly installed

## License

This software is licensed under the MIT License. See LICENSE.txt for details.

---

**Version**: 2.1.4
**Installation Date**: January 15, 2025
