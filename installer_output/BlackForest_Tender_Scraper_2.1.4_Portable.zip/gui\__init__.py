# gui/__init__.py
# Makes gui directory usable as a Python package.